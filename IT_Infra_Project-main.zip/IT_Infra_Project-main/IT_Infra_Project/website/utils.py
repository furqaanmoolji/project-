import secrets

def generate_token():
    return secrets.token_urlsafe(16)

def validate_token(session,token):
    return 'tokens' in session and token in session['token']

def store_tokens(session, token):
    if 'tokens' not in session:
        session['tokens']=[]
    session['token'].append(token)

